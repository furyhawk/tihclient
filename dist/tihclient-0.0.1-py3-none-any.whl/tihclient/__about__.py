# SPDX-FileCopyrightText: 2023-present Teck Meng <furyx@hotmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
